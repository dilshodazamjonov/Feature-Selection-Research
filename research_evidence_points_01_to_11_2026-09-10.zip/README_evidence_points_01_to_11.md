# Repository evidence for points 1–11

Prepared 10 September 2026 from `D:/python projects/Research`, including its local Git history at commit `90c3c4b8640de23c489129c0730cd1b64164335e`. This package contains repository facts, saved results, and explicitly identified calculations over existing records. No model, selector, LLM call, embedding, bootstrap test, DeLong test, hyperparameter search, or new robustness experiment was run.

The working tree no longer contains some historical experiment directories. For those runs, the package uses the earlier evidence ZIP retained in Git, without restoring deleted files or opening the external backup directories referenced by that export. `evidence_location`, `metric_source`, `original_source`, and `00_source_provenance.csv` distinguish working-tree evidence, historical reports, and retained Git exports. Historical report numbers retain their printed precision. Later supplied workbook/scorecard values are in `01_existing_supplied_aggregate_tables.csv`; they are not attached to an earlier run's other metrics or predictions.

Blank cells mean unavailable or inapplicable, not zero. `01_missing_metric_evidence.csv` lists missing requested metrics. All CSVs use UTF-8 with BOM. Source paths refer to this repository; source files and borrower-level records are not bundled.

## 1. Complete results and the five final Stability validation folds

[01_final_results.csv](01_final_results.csv) has 160 versioned method/configuration records: 32 original Home Credit/LendingClub v2 matrix rows; 64 classical-extension/review rows; 34 final amended Stability rows, including unavailable cells; four historical corrected Home Credit CLIP rows; six Stability CLIP rows; eight historical Home Credit voting rows; and 12 additional prospective voting/reference rows. The four prospective primary P=200 voting rows are already included among the 64 review rows. `01_current_run_inventory_including_pilots.csv` separately preserves the 20-run prospective inventory, including its four pilots. The six heavy-selector feasibility pilots are in `09_DEV_pilot_summary.csv`. The older 300-feature LendingClub v1 report is separately exported in `01_historical_LendingClub_v1_reported_results.csv`.

The requested columns are `dev_oof_auc`, `oot_auc`, `ks`, `brier`, `capture_at_10`, `score_psi`, `actual_feature_count`, `nogueira`, and `jaccard`. KS, Brier and Capture@10 concern OOT. Capture@10 is the fraction of positive cases captured in the highest-scored decile. Counts refer to the saved final selected original variables, except PCA, whose count describes components. Uncompleted selections remain blank. Full-feature Stability selections contain 1,959 variables, but their final models are unavailable; that distinction has its own count-scope column.

Pooled DEV OOF AUC is calculated from saved held-out probabilities where available; `dev_fold_auc_mean` is a separate quantity. The 36 full-baseline DEV probability files contain final-model in-sample scores and are not reported as OOF. Original historical matrix OOF probabilities are not present in the recovered evidence. Final Stability has some methods with only one to four completed validation predictions; `dev_oof_available_folds` and `dev_oof_status` identify those cases. `01_stability_dev_cell_accounting.csv` preserves all 170 final registered DEV cells and their statuses.

The five final Stability validation-fold sizes are **204,567; 203,798; 205,980; 201,466; 202,820**. They total **1,018,631** held-out rows. Training sizes, validation event counts, dates and row-identity hashes are in [01_stability_validation_fold_sizes.csv](01_stability_validation_fold_sizes.csv). The source is the five authenticated v3 fold manifests and the locked split specification.

Score PSI references differ by saved protocol: historical matrix/full-baseline and CLIP use full-DEV final-model in-sample scores; combination/prospective voting uses DEV OOF; final Stability uses its available DEV OOF folds and frozen bins. The result table records the reference per row.

## 2. Pure LLM eligibility: 529 to 391 and 675 to 161

**IV was involved in the original Home Credit and LendingClub v2 Pure LLM pipeline.** `src/credit_risk_fs/selectors/registry.py` configures missingness threshold 0.95, `min_iv=0.01`, `max_iv_for_leakage=0.5`, and IV/WOE `encode=True`. `LLMSelector.fit` in `llm_screening.py` applies missingness filtering, prepares the surviving frame for IV/WOE, fits the IV filter with training labels, and builds prompt metadata from the resulting frame.

The full-DEV Home Credit cache has **391 candidates and 391 IV-selected names**, from the 529-variable engineered universe: **138 removed in total**. The matching LendingClub v2 cache series has **161 candidates and 161 IV-selected names**, from 675: **514 removed in total**. Their exact candidate sets are preserved in [02_llm_eligible_feature_membership.csv](02_llm_eligible_feature_membership.csv). Separate counts of missingness-only removals versus each IV rejection reason are **not saved in the available artifacts**; no new screening fit was performed to supply them.

Screening and prompt statistics use **fold TRAIN** for DEV validation and **full DEV** for final OOT selection. Prompt statistics describe the post-IV/WOE candidate representation. Validation and OOT do not supply those computations. The Home Credit fold candidate counts are **374, 369, 365, 374, 372**; the corresponding LendingClub v2 series is **155, 154, 155, 157, 160**. Thus 391/161 are final full-DEV eligibility counts, not five common fold candidate counts. `02_llm_screening_and_cache_inventory.csv` records all 51 available cache variants, with scope, hashes and counts; variants with other counts are labelled separately.

Final Stability v3 uses a different contract: no IV screening; **1,068 of 1,959** predictors survive missingness <=0.90 measured on the earliest DEV training fold, **200,661 rows from 1 January through 28 March 2019**. The prompt uses feature names/descriptions and omits row statistics, labels, IV and OOT. One sealed ranking supplies K=20/40 across all folds and OOT. `02_stability_eligibility_settings.csv` and the frozen feature-availability JSON document this distinction.

## 3. Actual Nogueira universes

[03_nogueira_universes.csv](03_nogueira_universes.csv) records the denominator, fold coverage, membership rule and evidence status for each result.

| Result scope | Universe used |
| --- | ---: |
| Original Home Credit matrix and classical/prospective voting analyses | 529 engineered predictors |
| LendingClub v2 matrix and classical/prospective voting analyses | 675 engineered predictors |
| Final Stability classical methods | 1,959 engineered predictors |
| Final Stability LLM/stable-core supplement v3 | 1,068 frozen eligible predictors |
| Stability CLIP downstream selection, LR | fixed CLIP pool of 60 |
| Stability CLIP downstream selection, CatBoost | fixed CLIP pool of 100 |

**391/161 are not the original matrix Nogueira denominators.** The original matrix calculations used the full engineered universes, including features not selected after screening. Historical Home Credit CLIP/hybrid N=529 scalars were excluded in the retained earlier audit because of the pool/universe mismatch. The main table keeps the exclusion explicit; `06_historical_Nogueira_denominator_audit.csv` reproduces those historical N529 numbers from retained selections for audit, with no claim that they are corrected estimates.

The implementation is `1 - sum_j Var_sample(Z_j) / [mean_k*(1-mean_k/P)]`. Jaccard is the mean across all unordered pairs of available fold-selected feature sets. `reported_nogueira` preserves saved values where available. The repository returns 1 by convention when all features are selected; the formula's denominator is zero there. PCA's repeated PC labels do not authenticate identical fitted loadings; original-variable stability is marked inapplicable. Historical Home Credit voting has no executed DEV-fold selection stability under that protocol.

## 4. Stability full-feature and CLIP reference-run configuration

[04_reference_run_details.csv](04_reference_run_details.csv) identifies each saved full-feature reference and all six Stability CLIP results, with exact split, metrics and configuration source. The Stability split is **DEV 2019-01-01 through 2020-02-25; OOT 2020-02-26 through 2020-10-05**, with **1,221,743 DEV** and **304,916 OOT** rows.

The full-feature Stability LR/CatBoost configurations use 1,959 predictors and the frozen final-model settings. Both final OOT entries say **`unavailable`**, reason **`inherited_from_all_five_authenticated_dev_resource_stops`**. There is no completed numerical full-feature OOT baseline under this final registry. The saved selection of all variables remains distinct from completion of a model.

Stability CLIP uses that same **2020-02-26** cutoff, 1,959 ranked identities, fixed pools 60/100, RF-relevance/correlation-redundancy mRMR, K=20/40, and the saved sparse model preprocessing. Its six rows belong to `stability_clip_experiment_v1`.

**Matching 2020-02-01 baseline or CLIP results were not found** in the inspected repository evidence. The protocol's occurrence of `2020-02-01` is a monthly population `date_min`, not the train/OOT cutoff. The exported references retain the explicit **historical 2020-02-26 cutoff** label. `04_requested_cutoff_search.csv` records this gap.

## 5. Voting tests and the claimed 24 comparisons

[05_historical_voting_24_inventory.csv](05_historical_voting_24_inventory.csv) identifies **24 historically executed comparisons**: two models × four voting variants × three comparators. The exact variants are **`voting_llm_clip_top100_then_mrmr`**, **`voting_llm_clip_top200_then_mrmr`**, **`voting_llm_clip_top300_then_mrmr`**, and **`voting_llm_clip_mrmr_three_voter_direct`**. The first three refine an LLM+CLIP pool with RF/correlation mRMR; the fourth is recorded as direct three-voter selection. The comparators are **`statistical_mrmr`**, **`hybrid_llm_then_mrmr`**, and **`llm_corrected_clip_then_mrmr`**, with exact saved run IDs in the CSV. The historical mRMR implementation uses random-forest impurity relevance and absolute Pearson-correlation redundancy; it is not the later mutual-information implementation.

The retained test inventory records 120,053 aligned Home Credit OOT borrowers per pair, zero unmatched rows and zero target mismatches. AUC p-values use two-sided paired DeLong. Confidence intervals use paired stratified bootstrap, **2,000 repetitions, seed 20260706**. Holm adjusts the **24 AUC p-values together**. KS confidence intervals were calculated, but no KS p-value test is recorded in this family.

[05_historical_voting_24_results.csv](05_historical_voting_24_results.csv) contains voting/comparator AUCs, paired differences, 95% AUC confidence intervals, raw p-values and Holm-adjusted p-values for **20 recoverable comparisons**. The four LR versus full-pool mRMR comparisons were executed, but their numbers were withheld by the earlier export when its user changed the reference AUC. Their original powered-results file is no longer in this working tree and was not found in local Git history. Those four remain explicit missing numeric results; they are not new tests against the changed reference. Other rows retain their original 24-test Holm scope. Numerical KS intervals from that historical family are not retained in the recovered CSV.

The later prospective analysis is a **different 12-test study**, fully available in [05_current_cross_dataset_voting_12_tests.csv](05_current_cross_dataset_voting_12_tests.csv). Its voters are RF/correlation mRMR and Boruta, equal-weight normalized scores `1-(rank-1)/max(N-1,1)`, missing score zero, followed by CatBoost RFE. It excludes LLM/CLIP voters. It compares P=100/200/300 against a full-pool RF/correlation reference on both datasets and models. Holm uses **four separate families of three tests**; bootstrap seed is **20260721**, 2,000 repetitions. This CSV includes exact AUCs, deltas, raw/adjusted p-values, and AUC/KS/lift confidence intervals. The root six-row supplied inference table is preserved separately as aggregate evidence, not merged into either voting family.

## 6. CLIP implementation and historical before/after evidence

[06_clip_13_descriptors.csv](06_clip_13_descriptors.csv) gives the definitions and exact order: **missing_rate, unique_ratio, concentration_share, signed_log_mean, log_standard_deviation, clipped_skewness, normalized_entropy, is_numeric, is_categorical, is_binary, numeric_stats_valid, skewness_valid, entropy_valid**. Statistics use DEV distributions. Home Credit/Stability scale the first seven by training-feature median/IQR and clip to [-8,8], leaving six indicators unchanged. Corrected LendingClub transfer instead uses its frozen median-imputation/standard-scaling preprocessor on all 13 fields.

The saved configuration uses frozen `all-MiniLM-L6-v2` semantic embeddings, 384 dimensions; projection heads **384→64→32** and **13→16→32**, GELU, dropout 0.05, L2 normalization; **27,488 parameters**. Training uses symmetric identity-pair cross-entropy, fixed temperature 0.07, AdamW learning rate 0.001, weight decay 0.01, batch 64, maximum 80 epochs, gradient clipping 1, no scheduler, early-stop patience 15 and minimum improvement 0.0001. Seeds are **11, 22, 33, 44, 55**; each checkpoint minimizes source validation loss. Representation train/validation splitting is group-aware 80/20 with seed 42. `identity_equivalence_v2` masks same identities, verified aliases, exact DEV duplicates and documented identity transforms; same-family/text-similarity proximity is diagnostic rather than an automatic identity exclusion. Settings and source-specific differences are in `06_clip_training_anchor_ranking_settings.csv`.

Stability and LendingClub anchor construction uses four equal-duration DEV subwindows, representation-TRAIN feature identities, maximum adjacent-window PSI <=0.10, maximum missingness difference <=0.05, at least 100 nonmissing observations per subwindow, and 23 members ordered by PSI, missingness difference and feature identity. Numeric bins=10, categorical minimum count=50, epsilon=1e-6; buckets are fitted on the first subwindow. The 23 Stability member names and statistics are in `06_stability_anchor_members.csv`.

Historical Home Credit uses **23 previously frozen training-split stable-core members**. The code traces membership through `bootstrap_selection_frequency_if_available >= 0.8`, taking the maximum available frequency by feature in the evidence builder, then restricting to approved training identities. Those frequencies originate from the supervised bootstrap stable-core selector. The member centroid is computed in corrected consensus space; membership is not recomputed from corrected neighbours. Thus the projection's exclusion of labels as inputs and the origin of its anchor membership are distinct recorded implementation facts. The historical 23-name source file itself is outside the current working tree; its reference, count and frozen hashes are retained.

For seed s, `z_s(f)=normalize((T_s(f)+S_s(f))/2)`. Seeds are aligned to seed 11 by orthogonal Procrustes; the mean is normalized. Stability-native and Home Credit transfer rank by cosine similarity between this consensus and their normalized source anchor. LendingClub transfer uses the mean of five **seed-specific anchor similarities**. Ties use descending score then ascending feature name. Downstream selection uses RF/correlation mRMR on the fixed 60/100 pool and K=20/40.

[06_historical_CLIP_before_after.csv](06_historical_CLIP_before_after.csv) records **LLM→RF/correlation mRMR** versus **LLM→corrected CLIP→RF/correlation mRMR**:

| Model | OOT AUC before → after | Jaccard before → after | Score PSI before → after |
| --- | --- | --- | --- |
| LR | 0.738098 → 0.736996 | 0.404344 → 0.729185 | 0.003798 → 0.004898 |
| CatBoost | 0.762954 → 0.763820 | 0.296557 → 0.795195 | 0.008286 → 0.004094 |

The historical N529 scalars reproduce as **0.553104→0.833713** for LR and **0.407715→0.875593** for CatBoost. They are labelled **unvalidated historical denominator values**, with the earlier audit's exclusion retained; a validated corrected before/after Nogueira result is absent. The change in this comparison inserts corrected CLIP screening/reordering. It is not a controlled before/after test of the pairing repair alone. No additional original-versus-corrected CLIP training-ablation AUC table was recovered. The six separate Stability CLIP pipelines are exported independently.

## 7. Selected features, descriptions, source families and recency

[07_selected_features_with_descriptions.csv](07_selected_features_with_descriptions.csv) contains **72,426 saved feature-selection records** covering final full-DEV and available fold selections. It includes run identity, selection scope/order, description, source family, formula/operation, semantic group and provenance. [07_feature_dictionary.csv](07_feature_dictionary.csv) contains 3,299 unique dataset-feature entries. LendingClub v2 and Stability use their saved exact metadata. Home Credit engineered descriptions use the repository's prefix/aggregation description rules, explicitly labelled as such. `07_method_feature_overlaps.csv` gives 646 within-dataset/model/cohort method pairs, intersection counts, Jaccard and overlapping names; it does not select pairs based on performance.

[07_homecredit_recency_eligibility_and_selection.csv](07_homecredit_recency_eligibility_and_selection.csv) lists 113 recency/date-derived fields and controls. **`PREV_recent_decision_MIN/MEAN/SUM/VAR` and `PREV_DAYS_DECISION_MIN/MEAN/SUM/VAR`** are in the 529-variable predictor universe and in the 391-feature full-DEV LLM eligibility set. Each is selected in at least one saved final run. **`PREV_DAYS_DECISION_MAX`** is also an eligible classical predictor and is selected in saved runs, but is absent from that full-DEV LLM candidate set. `PREV_recent_decision_MAX`, raw `DAYS_DECISION`, `recent_decision`, and `application_time_proxy` are explicit excluded controls. The exact selecting run IDs are provided rather than inferred from a method's displayed score.

`07_feature_engineering_specification.csv` records the joins, aggregations, ratio/payment features, temporal proxy, exclusions and preprocessing. The Home Credit code first copies previous-application `DAYS_DECISION` into `recent_decision`, aggregates both fields and uses the maximum copied value as the split variable. Its retained temporal-as-of audit records five auxiliary tables requiring manual confirmation; it does not certify row-level as-of availability for them.

## 8. Outcome definitions, terms, cohorts and maturity

LendingClub retains **Fully Paid** and **Does not meet the credit policy. Status:Fully Paid** as good; **Charged Off**, **Default**, and **Does not meet the credit policy. Status:Charged Off** as bad. Current, grace, late, issued, missing or other unrecognized statuses are excluded. The raw table has **2,260,701 rows**; **1,348,099 retained**, **912,602 excluded**. This includes 33 missing-status rows among exclusions. The retained labels are **1,078,739 good** and **269,360 bad**.

The 36-month retained group has **1,023,206 rows, 163,926 bad (16.0208%)**; the 60-month group has **324,893 rows, 105,434 bad (32.4519%)**. `08_LendingClub_status_filter_counts.csv` gives status counts; `08_LendingClub_status_by_term_and_issue_cohort.csv` gives all 1,024 raw status×term×cohort combinations, tabulated from existing data. `08_LendingClub_existing_issue_cohort_by_term.csv` copies the existing 243-row resolved-status audit. `08_LendingClub_year_term_and_partition_counts.csv` supplies the annual/term/DEV/OOT aggregation, including 2014–2015 DEV and 2016 OOT.

The existing target note estimates observation end **2019-05-01** using maximum outcome-related dates. It documents resolved-status filtering and separate term/cohort audits. **No saved fixed-horizon, fully matured-loan sensitivity refit or survival/censoring experiment was found.** These audits do not establish per-loan label availability at every simulated training cutoff.

`08_target_horizons_and_label_availability.csv` records the known target definitions. Home Credit's supplied description leaves **X days / first Y installments** unspecified. LendingClub uses resolved status at the snapshot; 36/60 months are contractual terms, with no common fixed default horizon documented. Stability uses the supplied binary `target`; no numerical outcome horizon or per-case label-availability timestamp was recovered. No numerical horizons were inferred.

## 9. Tuning provenance and verification of Boruta/RFE settings

K=20 for LR and K=40 for CatBoost, and the final model settings, are frozen in the repository configuration. **An originating DEV hyperparameter trial history or 20-versus-40 budget optimization study was not found.** The feature set/DEV partition that originally selected those model settings cannot be established from the recovered evidence. `09_existing_tuning_provenance.csv` records this limitation; `09_frozen_model_and_dataset_settings.csv` preserves the exact configured settings and dataset inventories.

There are six completed heavy-selector **DEV fold-1 feasibility pilots**, with performance evaluation explicitly false and no OOT access. They use **16,242 training / 16,720 validation rows and 529 candidates** for Home Credit, and **83,283 / 114,267 rows and 675 candidates** for LendingClub v2. Each tests CatBoost SHAP, Boruta, or RFE. Home Credit Boruta confirms 26 features; LendingClub confirms 161 and uses top 40. These pilots support feasibility/configuration freeze, not an AUC-based optimization claim. Exact counts, timings and config hashes are in `09_DEV_pilot_summary.csv` and the detailed pilot CSV.

Verification confirms canonical Boruta: RF 500/depth 6, Boruta automatic tree count, 10 iterations, percentile 100, alpha 0.05, two-step correction, seed 42, confirmed-only support without rejected-feature padding. Canonical CatBoost RFE uses 500 iterations, depth 6, learning rate 0.05 and floor(20% of surviving features) removal, bounded to stop at K. Historical registry settings differ: Boruta 15 iterations and integer-step RFE 10. `09_verified_Boruta_RFE_and_budgets.csv` preserves the canonical configuration fields. The DEV combination review records no configuration selection/removal/tuning/reordering; P=100/200/300 are preregistered pools, with P=200 primary for prospective voting.

## 10. Existing runtime and memory measurements

`10_saved_run_runtime_and_memory.csv` exports 60 saved resource records. Their four dedicated selection/training/prediction/evaluation timing slots are null; total time is available. `10_saved_OOT_worker_stage_measurements.csv` separately preserves the 64 review rows' available fit, prediction, worker-wall-time and memory fields. These have their original worker/reference scopes and are not relabelled total pipeline costs.

`10_voting_runtime_summary.csv` preserves 16 prospective runs with interruptions/resume information and cached-path limitations. `10_voting_log_stage_spans.csv` contains 80 log-marker spans and explicitly says no instrumented stage timer is available; spans may include pauses. `10_CLIP_saved_fold_metrics_and_timings.csv` contains 30 saved fold records with elapsed seconds and RSS observations; point RSS is not labelled peak RSS. Stability supervisor/attempt measurements are in `10_Stability_supervisor_measurements.csv`. The six feasibility pilot runtimes are separately scoped in point 9.

The recorded Stability machine profile is **Windows 11 10.0.26200, Intel Core i7-13620H, 10 physical cores / 16 logical processors, 42,555,686,912 bytes RAM**. Run preflights record **NVIDIA GeForce RTX 4060 Laptop GPU, approximately 8 GiB VRAM**; the documented downstream experiments and CLIP projection training use CPU. Estimator thread caps are four in the frozen executions. `10_recorded_run_hardware.csv` preserves per-run dates, accelerator, hardware capacity and Git commit; `10_Stability_recorded_hardware_plan.csv` preserves the recorded machine profile. CPU model is absent from individual preflight fields and is not silently backfilled there.

LLM rankings, embeddings, completed seeds and downstream artifacts have reuse/cache paths. The available records do **not** constitute a controlled cold-cache versus warm-cache benchmark. Zero measured GPU allocation for a CPU run is preserved as a recorded measurement; missing measurements stay blank. Packaging time is not added to experimental timing.

## 11. Existing robustness/control experiments and absences

[11_existing_controls_and_absences.csv](11_existing_controls_and_absences.csv) records the following:

- **Controlled independent LLM replication with fully identical authenticated requests: not established.** The 51 existing cache payloads contain 12 groups with multiple distinct response IDs under matching saved base-prompt hashes, requested model and temperature. Six LendingClub v2 groups contain four different responses each, with cache feature budgets 20/40/60/100; six other cache groups contain two responses each. Exact terminal retry request text and historical retry attempts are not saved. `11_existing_LLM_response_identity_records.csv` and `11_same_base_prompt_response_groups.csv` provide these facts without claiming a planned replication study.
- **Controlled prompt ablations: absent** in inspected evidence.
- **Voting comparisons holding exact candidate-feature membership and downstream reduction constant across LLM/CLIP/component controls: absent** in inspected evidence.
- **Prospective voting pool-budget sensitivity: present**, P=100/200/300 with the distinct statistical-voter protocol described in point 5.
- **Five CLIP projection-seed runs: present**, with source-validation checkpoint selection and frozen consensus.
- **Random-k and full-feature controls: present**, including unavailable Stability full-feature final models. Fixed-seed repeated random-k sets are not independent random resampling experiments.
- **Stability LLM v3 retry history: present**, one rejected attempt followed by one accepted attempt; these are not two accepted replicate models.
- **Maturity-restricted robustness experiment: absent**; existing term/cohort audits are exported.

`00_validation_checks.csv` records the performed evidence checks. `00_package_manifest.csv` lists the delivered files and hashes. Missing results remain missing; no new experiments were launched to fill them.
